# **Support discord server: https://discord.gg/RTseVPF8MA**

## **These bookmarklets are also on: https://schoolcheats.net/blooket**

# cafe

This cheat only works in cafe game mode!

# getCoins.js

New scripts are at:
https://schoolcheats.net/blooket

# infiniteFoodLevel.js

New scripts are at:
https://schoolcheats.net/blooket

# stockInfiniteFood.js

New scripts are at:
https://schoolcheats.net/blooket
