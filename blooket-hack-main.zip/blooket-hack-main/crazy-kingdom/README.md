# **Support discord server: https://discord.gg/RTseVPF8MA**

## **These bookmarklets are also on: https://schoolcheats.net/blooket**

# crazy-kingdom

This cheat only works in crazy kingdom gamemode!

# ChoiceESP.js

New scripts are at:
https://schoolcheats.net/blooket

# MaxResources.js

New scripts are at:
https://schoolcheats.net/blooket

# NoTaxes.js

New scripts are at:
https://schoolcheats.net/blooket

# SetGuests.js

New scripts are at:
https://schoolcheats.net/blooket

# SkipGuests.js

New scripts are at:
https://schoolcheats.net/blooket
