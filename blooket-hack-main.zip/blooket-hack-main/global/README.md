# **Support discord server: https://discord.gg/RTseVPF8MA**

## **These bookmarklets are also on: https://schoolcheats.net/blooket**

# global

All these cheats in the folder can be used outside games

# addTokens.js

note: **This cheat also includes adding max xp for the day**

New scripts are at:
https://schoolcheats.net/blooket

# bypassRandomName.js

New scripts are at:
https://schoolcheats.net/blooket

# getAllBlooksInGame.js

New scripts are at:
https://schoolcheats.net/blooket

# getEveryAnswerCorrect.js

New scripts are at:
https://schoolcheats.net/blooket

# spamOpenBoxes.js

New scripts are at:
https://schoolcheats.net/blooket

# sellDupeBlooks.js

New scripts are at:
https://schoolcheats.net/blooket
