# **Support discord server: https://discord.gg/RTseVPF8MA**

## **These bookmarklets are also on: https://schoolcheats.net/blooket**

# tower-of-doom

This cheat only works in tower of doom game mode!

# addCoins.js

New scripts are at:
https://schoolcheats.net/blooket

# lowerEnemyCharisma.js

New scripts are at:
https://schoolcheats.net/blooket

# lowerEnemyStrength.js

New scripts are at:
https://schoolcheats.net/blooket

# lowerEnemyWisdom.js

New scripts are at:
https://schoolcheats.net/blooket

# lowerAllEnemyStats.js

New scripts are at:
https://schoolcheats.net/blooket
