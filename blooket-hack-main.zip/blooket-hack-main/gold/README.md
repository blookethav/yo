# **Support discord server: https://discord.gg/RTseVPF8MA**

## **These bookmarklets are also on: https://schoolcheats.net/blooket**

# gold

This cheat only works in gold game mode!

# chest-ESP.js

New scripts are at:
https://schoolcheats.net/blooket

# getGold.js

New scripts are at:
https://schoolcheats.net/blooket
