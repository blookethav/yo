# **Support discord server: https://discord.gg/RTseVPF8MA**

## **These bookmarklets are also on: https://schoolcheats.net/blooket**

# racing 

This cheat only works in racing game mode!

# instantWin.js

New scripts are at:
https://schoolcheats.net/blooket
