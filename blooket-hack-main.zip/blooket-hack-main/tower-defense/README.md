# **Support discord server: https://discord.gg/RTseVPF8MA**

## **These bookmarklets are also on: https://schoolcheats.net/blooket**

# tower-defense

This cheat only works in tower defense game mode!

# changeGameRound.js

New scripts are at:
https://schoolcheats.net/blooket


# clearEnemies.js

New scripts are at:
https://schoolcheats.net/blooket


# getCash.js

New scripts are at:
https://schoolcheats.net/blooket
