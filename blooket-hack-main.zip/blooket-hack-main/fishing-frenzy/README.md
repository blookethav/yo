# **Support discord server: https://discord.gg/RTseVPF8MA**

## **These bookmarklets are also on: https://schoolcheats.net/blooket**

# fishing-frenzy

This cheat only works in fishing frenzy game mode!

# setWeight.js

New scripts are at:
https://schoolcheats.net/blooket
