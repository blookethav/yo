# **Support discord server: https://discord.gg/RTseVPF8MA**

## **These bookmarklets are also on: https://schoolcheats.net/blooket**

# crypto

This cheat only works in crypto hack game mode!

# getCrypto.js

New scripts are at:
https://schoolcheats.net/blooket

# getOtherUsersPassword.js

New scripts are at:
https://schoolcheats.net/blooket
