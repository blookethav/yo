# **Support discord server: https://discord.gg/RTseVPF8MA**

## **These bookmarklets are also on: https://schoolcheats.net/blooket**

# factory

This cheat only works in factory game mode!

# getCash.js

New scripts are at:
https://schoolcheats.net/blooket

# getMegaBot.js

New scripts are at:
https://schoolcheats.net/blooket
